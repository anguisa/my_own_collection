# Ansible Collection - my_netology.my_own_collection

Documentation for the collection.

Модуль `my_own_module` для создания и заполнения текстового файла.
Роль `my_own_role`, использующая данный модуль.